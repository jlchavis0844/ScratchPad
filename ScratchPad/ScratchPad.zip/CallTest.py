'''
Created on Jan 29, 2018

@author: jchavis
'''

import os, tkinter, ctypes, json, requests
import unicodecsv as csv
from io import BytesIO
import tkinter.filedialog as fd  # for picking the file
from datetime import datetime
from datetime import timedelta
from dateutil import tz

def loadOwners():
    global token
    global owners
    if token is None or token == '':
        token = getToken()
    
    oheaders = {'Accept': 'application/json',
                 'Content-Type': 'application/json',
                 'Authorization': 'Bearer ' + token}
    
    oURL = 'https://api.getbase.com/v2/users?per_page=100&status=active'
    oresponse = requests.get(url=oURL, headers=oheaders, verify = True)
    oresponse_json = json.loads(oresponse.text)  # read in the response JSON
    items = oresponse_json['items']
    owners = {}
    
    for item in items:
        owners[item['data']['name']] = item['data']['id']

# this function finds the owner id for the given name and returns owner_id as an int
def getOwner(ownerNum):
    global owners
    if not owners or len(owners) == 0:
        loadOwners()
    
    if(ownerNum == "" or ownerNum == " " or ownerNum is None):
        return ""
    else:
        #return owners[ownerName]
        for k,v in owners.items():
            if(v == ownerNum):
                if(k == ""):
                    return "Not Found"
                else:
                    return k
        return "Not Found"

#This function will check for a text file called token which holds the Base API Token in plain text
# this token will be loaded, read, and stored as the token variable that is returned
# the function will read this computer's name and then check the network shared drive locations
#     \\NAME\now\token
#     \\NAME\Noe
# If the file is not located, a file picker will be loaded for the user to find the token file.
def getToken():
    path = ""
    if(os.path.isfile("C:\\Apps\\NiceOffice\\token")):
        path = "C:\\Apps\\NiceOffice\\token"
    elif(os.path.isfile("\\\\" + os.environ['COMPUTERNAME'] + "\\noe\\token")):
        path = "\\\\" + os.environ['COMPUTERNAME'] + "\\noe\\token"
    elif(os.path.isfile("\\\\" + os.environ['COMPUTERNAME'] + "\\NiceOffice\\token")):
        path = "\\\\" + os.environ['COMPUTERNAME'] + "\\NiceOffice\\token"
    else:
        ctypes.windll.user32.MessageBoxW(0, "A token file was not found in your NOE folder, please choose the token file", "Token File", 0)
        FILEOPENOPTIONS = dict(filetypes=[('TOKEN file', '*.*')], title=['Choose token file'])
        root = tkinter.Tk()  # where to open
        root.withdraw()
        # withdraw()  # hide Frame
        path = fd.askopenfilename(**FILEOPENOPTIONS)  # choose a file
    if(path == ""):
        ctypes.windll.user32.MessageBoxW(0, "No file was chosen, quiting", "Token File", 0)
        exit()
    
    file = open(path, 'r', encoding="utf8")
    token = file.read()
    file.close()
    # print(token)
    return token


def timeConvert(intime):
    thisTime = intime.replace('T',' ').replace('Z','')
    # METHOD 2: Auto-detect zones:
    from_zone = tz.tzutc()
    to_zone = tz.tzlocal()
    
    # utc = datetime.utcnow()
    utc = datetime.strptime(thisTime, '%Y-%m-%d %H:%M:%S')
    
    # Tell the datetime object that it's in UTC time zone since 
    # datetime objects are 'naive' by default
    utc = utc.replace(tzinfo=from_zone)
    
    # Convert time zone
    return utc.astimezone(to_zone)

def writeAndQuit(response, log):
    log.write(response.text)
    print('ERROR: received status code: ' + str(response.status_code) + '\n')
    #log.close()
    #exit(response.status_code)
    
#case insensitive check of all the current api tags with the current tag. If match is found, true, false otherwise
def duplicateTagCheck(APItags, currTag):
    for x in range(len(APItags)):
        if(APItags[x].lower() == currTag.lower()):
            return True
    return False

# need callback function for Async Unirest calls
#def callBack_function(response):
#    print('Empty function, response code was ' + response.code)
    
    
# Setup for the file picker
FILEOPENOPTIONS = dict(defaultextension='.csv', filetypes=[('CSV file', '*.csv'), ('All files', '*.*')])
time = datetime.now().strftime('%Y-%m-%d_%H%M%S')  # get time stamp for the log writing.
path = os.path.dirname(__file__)  # get current path

# load in the API token, for security, the token is saved as plain text locally in the NOE folder
token = getToken()

# get input file
# root = tkinter.Tk()  # where to open
# root.withdraw()  # hide Frame
# csv_path = fd.askopenfilename(**FILEOPENOPTIONS)  # choose a file
# 
# if(csv_path is None or csv_path == ""):  # if the file picker is closed
#     exit("No file chosen")  # shutdown before log is written

owners = {}


file = open(path + '\\logs\\CallReports' + time + '.txt', 'w+')  # create and open the log file for this session
file.write("starting Call Testing at " + time + '\n')  # write to log
#file.write("using CSV: " + csv_path + '\n')
rowCntr = -1

# start API call setup, let us try Async calls with unirest libs
headers = {'Accept': 'application/json',
           'Content-Type': 'application/json',
           'Authorization': 'Bearer ' + token}

baseURL = 'https://api.getbase.com/v2/calls'
myParams = {'per_page': '100'}
response = requests.get(baseURL, myParams, headers = headers)
dayLimit = (datetime.today() - timedelta(days=7)).replace(tzinfo=tz.tzlocal())

callArr = []

# with open('H:\\Desktop\\callOut.csv', encoding="utf8", newline='', errors='ignore') as csvfile:  # open file as UTF-8
#     reader = csv.reader(csvfile, delimiter=',')  # makes the file a csv reader

if(response.status_code == 200):
    callData = json.loads(response.text)['items']
    for d in callData:
        #print(timeConvert(d['data']['made_at']))
        thisCall = {}
        thisCall['id'] = d['data']['id']
        thisCall['user_id'] = d['data']['user_id']
        thisCall['owner_name'] = getOwner(d['data']['user_id'])
        thisCall['summary'] = d['data']['summary']
        thisCall['recording_url'] = d['data']['recording_url']
        thisCall['outcome_id'] = d['data']['outcome_id']
        thisCall['duration'] = d['data']['duration']
        thisCall['phone_number'] = d['data']['phone_number']
        thisCall['incoming'] = d['data']['incoming']
        thisCall['missed'] = d['data']['missed']
        thisCall['updated_at'] = timeConvert(d['data']['updated_at'])
        thisCall['external_id'] = d['data']['external_id']
        thisCall['associated_deal_ids'] = str(d['data']['associated_deal_ids'])
        thisCall['made_at'] = timeConvert(d['data']['made_at'])
        thisCall['resource_id'] = d['data']['resource_id']
        thisCall['resource_type'] = d['data']['resource_type']
        print(thisCall['owner_name'])
        
        if(thisCall['made_at'] >= dayLimit):
            #thisCall = {k: str(v).encode("utf-8") for k,v in thisCall.items()}
            callArr.append(thisCall)
                      
#     keys = callArr[0].keys()
#     print(keys)
#     
    while(timeConvert(callData[len(callData)-1]['data']['made_at']) >= dayLimit):
        nextURL = json.loads(response.text)['meta']['links']['next_page']
        response = requests.get(nextURL, headers = headers)
        callData = json.loads(response.text)['items']
        print(callData[99]['data']['made_at'])
        for d in callData:
            thisCall = {}
            thisCall['id'] = d['data']['id']
            thisCall['user_id'] = d['data']['user_id']
            thisCall['owner_name'] = getOwner(d['data']['user_id'])
            thisCall['summary'] = d['data']['summary']
            thisCall['recording_url'] = d['data']['recording_url']
            thisCall['outcome_id'] = d['data']['outcome_id']
            thisCall['duration'] = d['data']['duration']
            thisCall['phone_number'] = d['data']['phone_number']
            thisCall['incoming'] = d['data']['incoming']
            thisCall['missed'] = d['data']['missed']
            thisCall['updated_at'] = timeConvert(d['data']['updated_at'])
            thisCall['external_id'] = d['data']['external_id']
            thisCall['associated_deal_ids'] = str(d['data']['associated_deal_ids'])
            thisCall['made_at'] = timeConvert(d['data']['made_at'])
            thisCall['resource_id'] = d['data']['resource_id']
            thisCall['resource_type'] = d['data']['resource_type']
              
            if(thisCall['made_at'] >= dayLimit):
                #thisCall = {k: str(v).encode("utf-8") for k,v in thisCall.items()}
                callArr.append(thisCall) 


if(len(callArr) > 0):  # if merges were detected
    print("calls found, printing list\n")
    with open('H:\\Desktop\\CallData.csv', 'wb') as f:  # open csv
        w = csv.DictWriter(f, callArr[0].keys(), lineterminator='\n')  # make writer
        w.writeheader()  # write header row
        for call in callArr:  # write the merges to the merge CSV
            #w.writerow({k:v.decode() for k,v in call.items()})
            w.writerow(call)
            #print({k:v.decode() for k,v in call.items()})
    
        
print("Goodbye!")
file.close()
        